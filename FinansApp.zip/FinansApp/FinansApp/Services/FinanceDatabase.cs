using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using SQLite;
using FinansApp.Model;

namespace FinansApp.Services
{
    public class FinanceDatabase
    {
        private SQLiteAsyncConnection? Database;

        private async Task Init()
        {
            if (Database is not null) return;
            var dbPath = Path.Combine(FileSystem.AppDataDirectory, "Finance.db3");
            Database = new SQLiteAsyncConnection(dbPath);
            await Database.CreateTableAsync<Transaction>();
        }

        // Parameterized: Get all transactions ordered by Date descending
        public async Task<List<Transaction>> GetTransactionsAsync()
        {
            await Init();
            string sql = "SELECT * FROM [Transaction] ORDER BY [Date] DESC";
            return await Database!.QueryAsync<Transaction>(sql);
        }

        // Parameterized: Save transaction (Insert or Update) using raw parameterized queries
        public async Task<int> SaveAsync(Transaction item)
        {
            await Init();
            if (item.Id != 0)
            {
                string sql = "UPDATE [Transaction] SET [Description] = ?, [Amount] = ?, [Date] = ?, [Category] = ?, [IsIncome] = ? WHERE [Id] = ?";
                return await Database!.ExecuteAsync(sql, item.Description, item.Amount, item.Date, item.Category, item.IsIncome ? 1 : 0, item.Id);
            }
            else
            {
                string sql = "INSERT INTO [Transaction] ([Description], [Amount], [Date], [Category], [IsIncome]) VALUES (?, ?, ?, ?, ?)";
                int rows = await Database!.ExecuteAsync(sql, item.Description, item.Amount, item.Date, item.Category, item.IsIncome ? 1 : 0);
                if (rows > 0)
                {
                    // Retrieve auto-generated ID
                    item.Id = await Database!.ExecuteScalarAsync<int>("SELECT last_insert_rowid()");
                }
                return rows;
            }
        }

        // Parameterized: Delete transaction
        public async Task<int> DeleteAsync(Transaction item)
        {
            await Init();
            string sql = "DELETE FROM [Transaction] WHERE [Id] = ?";
            return await Database!.ExecuteAsync(sql, item.Id);
        }

        // Parameterized: Get Total Income (Gelir)
        public async Task<double> GetTotalIncomeAsync()
        {
            await Init();
            string sql = "SELECT SUM([Amount]) FROM [Transaction] WHERE [IsIncome] = ?";
            var result = await Database!.ExecuteScalarAsync<double?>(sql, 1);
            return result ?? 0.0;
        }

        // Parameterized: Get Total Expense (Gider)
        public async Task<double> GetTotalExpenseAsync()
        {
            await Init();
            string sql = "SELECT SUM([Amount]) FROM [Transaction] WHERE [IsIncome] = ?";
            var result = await Database!.ExecuteScalarAsync<double?>(sql, 0);
            return result ?? 0.0;
        }

        // Parameterized: Calculate Net Balance
        public async Task<double> GetTotalBalanceAsync()
        {
            double income = await GetTotalIncomeAsync();
            double expense = await GetTotalExpenseAsync();
            return income - expense;
        }

        // Parameterized: Get Category-based spending/earning reports (GROUP BY SUM)
        public async Task<List<CategorySummary>> GetCategoryReportAsync()
        {
            await Init();
            // Secure parameterized group-by query
            string sql = "SELECT [Category], SUM([Amount]) AS [TotalAmount], [IsIncome] FROM [Transaction] GROUP BY [Category], [IsIncome] ORDER BY [TotalAmount] DESC";
            return await Database!.QueryAsync<CategorySummary>(sql);
        }
    }
}
