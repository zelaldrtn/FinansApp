using System;
using System.Globalization;
using Microsoft.Maui.Graphics;

namespace FinansApp.Converters
{
    public class IncomeToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isIncome)
            {
                return isIncome 
                    ? Color.FromArgb("#2E7D32") // Pastel Green
                    : Color.FromArgb("#C62828"); // Soft Red
            }
            return Color.FromArgb("#2C2C2C"); // Dark Charcoal fallback
        }

        public object? ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
