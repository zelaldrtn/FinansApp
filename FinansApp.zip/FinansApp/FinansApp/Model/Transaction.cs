﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace FinansApp.Model
{
    public class Transaction
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string? Description { get; set; } //harcama açıklaması
        public double Amount { get; set; } //tutar
        public DateTime Date { get; set; } //işlem tarihi
        public string? Category { get; set; } //mutfak, kira, maaş vb.
        public bool IsIncome { get; set; } //true ise gelir, false ise gider
    }
}
