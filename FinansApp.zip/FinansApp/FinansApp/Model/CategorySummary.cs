namespace FinansApp.Model
{
    public class CategorySummary
    {
        public string Category { get; set; } = string.Empty;
        public double TotalAmount { get; set; }
        public bool IsIncome { get; set; }
    }
}
