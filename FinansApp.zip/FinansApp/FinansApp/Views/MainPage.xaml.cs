using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;
using FinansApp.Model;
using FinansApp.Services;

namespace FinansApp.Views
{
    public partial class MainPage : ContentPage
    {
        private readonly FinanceDatabase _database;
        private readonly IServiceProvider _serviceProvider;

        public MainPage(FinanceDatabase database, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _database = database;
            _serviceProvider = serviceProvider;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await LoadData();
        }

        private async Task LoadData()
        {
            try
            {
                // 1. Veritabanından tüm işlemleri çek ve listeye bağla
                var transactions = await _database.GetTransactionsAsync();
                FinanceList.ItemsSource = transactions;

                // 2. Ciro / Toplam Hesaplamalarını asenkron olarak SQLite'tan çek
                double totalIncome = await _database.GetTotalIncomeAsync();
                double totalExpense = await _database.GetTotalExpenseAsync();
                double netBalance = totalIncome - totalExpense;

                // Kartlardaki metinleri yerel para formatında göster
                IncomeLabel.Text = totalIncome.ToString("C2");
                ExpenseLabel.Text = totalExpense.ToString("C2");
                BalanceLabel.Text = netBalance.ToString("C2");

                // 3. Kategori Bazlı Raporları Çek ve BindableLayout'a bağla
                var categoryReports = await _database.GetCategoryReportAsync();
                BindableLayout.SetItemsSource(CategoryReportsLayout, categoryReports);
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlertAsync("Hata", "Veriler yüklenirken bir sorun oluştu: " + ex.Message, "Tamam");
            }
        }

        /// <summary>
        /// Listeden bir öğe kaydırılıp "Sil"e basıldığında tetiklenir.
        /// </summary>
        private async void OnDelete(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var item = swipeItem?.CommandParameter as Transaction;

            if (item == null) return;

            bool confirm = await Shell.Current.DisplayAlertAsync("Silme Onayı", $"'{item.Description}' işlemini silmek istediğinize emin misiniz?", "Evet", "Hayır");

            if (confirm)
            {
                await _database.DeleteAsync(item);
                await LoadData(); // Listeyi ve bakiyeleri tazele
            }
        }

        /// <summary>
        /// Listeden bir öğeye tıklandığında (Düzenleme için)
        /// </summary>
        private async Task OnEditTransaction(Transaction item)
        {
            var editPage = _serviceProvider.GetService<TransactionEditPage>();
            if (editPage != null)
            {
                editPage.SetTransaction(item);
                await Navigation.PushAsync(editPage);
            }
        }

        // XAML'deki SelectionChanged burayı tetikler
        private async void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var current = e.CurrentSelection.FirstOrDefault() as Transaction;

            if (current != null)
            {
                await OnEditTransaction(current);
            }

            // Seçimi temizliyoruz (Tekrar tıklanabilmesi için)
            ((CollectionView)sender).SelectedItem = null;
        }

        // Floating Action Button (FAB) ve Ekleme İşlemi
        private async void OnAddClicked(object sender, EventArgs e)
        {
            var editPage = _serviceProvider.GetService<TransactionEditPage>();
            if (editPage != null)
            {
                // Sayfaya yeni ve ön tanımlı bir işlem gönderiyoruz
                editPage.SetTransaction(new Transaction
                {
                    IsIncome = false, // Varsayılan Gider
                    Date = DateTime.Now,
                    Category = "Diğer"
                });

                await Navigation.PushAsync(editPage);
            }
        }
    }
}
