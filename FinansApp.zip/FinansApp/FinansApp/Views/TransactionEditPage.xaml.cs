using System;
using Microsoft.Maui.Controls;
using FinansApp.Model;
using FinansApp.Services;

namespace FinansApp.Views
{
    public partial class TransactionEditPage : ContentPage
    {
        private readonly FinanceDatabase _database;
        public Transaction? Item { get; set; }

        public TransactionEditPage(FinanceDatabase database)
        {
            InitializeComponent();
            _database = database;
        }

        /// <summary>
        /// Sayfa açılmadan önce veriyi yüklemek için kullanılır
        /// </summary>
        public void SetTransaction(Transaction transaction)
        {
            Item = transaction;

            // XAML'deki x:Name="DescEntry"
            DescEntry.Text = Item.Description;

            // XAML'deki x:Name="AmountEntry"
            AmountEntry.Text = Item.Amount > 0 ? Item.Amount.ToString() : string.Empty;

            // XAML'deki x:Name="IncomeSwitch"
            IncomeSwitch.IsToggled = Item.IsIncome;

            // XAML'deki x:Name="TransDate"
            TransDate.Date = Item.Date == default ? DateTime.Now : Item.Date;

            // XAML'deki x:Name="CategoryPicker"
            CategoryPicker.SelectedItem = Item.Category ?? "Diğer";
        }

        private async void OnSaveClicked(object sender, EventArgs e)
        {
            try
            {
                if (Item == null) return;

                // 1. Doğrulama (Validation)
                if (string.IsNullOrWhiteSpace(DescEntry.Text))
                {
                    await Shell.Current.DisplayAlertAsync("Hata", "Lütfen bir açıklama girin.", "Tamam");
                    return;
                }

                // Sayısal format kontrolü
                if (!double.TryParse(AmountEntry.Text, out double amount) || amount <= 0)
                {
                    await Shell.Current.DisplayAlertAsync("Geçersiz Tutar", "Lütfen 0'dan büyük geçerli bir sayı girin.", "Tamam");
                    return;
                }

                // 2. Veriyi Modele Aktar
                Item.Description = DescEntry.Text.Trim();
                Item.Amount = amount;
                Item.IsIncome = IncomeSwitch.IsToggled;
                Item.Date = TransDate.Date ?? DateTime.Now;
                Item.Category = CategoryPicker.SelectedItem?.ToString() ?? "Diğer";

                // 3. Veritabanı Kaydı (Güvenli parametreli sorgu arka planda çalışır)
                await _database.SaveAsync(Item);

                // 4. Geri Dön
                await Shell.Current.Navigation.PopAsync();
            }
            catch (Exception ex)
            {
                // Beklenmedik hataları yakala
                await Shell.Current.DisplayAlertAsync("Sistem Hatası", ex.Message, "Kapat");
            }
        }

        private async void OnCancelClicked(object sender, EventArgs e)
        {
            // Kullanıcı vazgeçtiğinde doğrudan geri dön
            await Shell.Current.Navigation.PopAsync();
        }
    }
}
