﻿using FinansApp.Model;
using FinansApp.Views;
using FinansApp.Services;

namespace FinansApp;

public partial class AppShell : Shell
{
    // Komutları tanımlıyoruz
    public Command AddIncomeCommand { get; }
    public Command AddExpenseCommand { get; }

    public AppShell()
    {
        InitializeComponent();

        // Komutların ne yapacağını (Action) belirliyoruz
        AddIncomeCommand = new Command(async () => await NavigateToEdit(true));
        AddExpenseCommand = new Command(async () => await NavigateToEdit(false));

        // XAML'deki {Binding} ifadelerinin bu sınıftaki komutları bulması için
        BindingContext = this;
    }

    private async Task NavigateToEdit(bool isIncome)
    {
        try
        {
            // Dependency Injection (DI) konteynerından sayfayı istiyoruz
            var services = Handler?.MauiContext?.Services;
            var editPage = services?.GetService<TransactionEditPage>();

            if (editPage != null)
            {
                // Sayfaya yeni ve ön tanımlı bir işlem gönderiyoruz
                editPage.SetTransaction(new Transaction
                {
                    IsIncome = isIncome,
                    Date = DateTime.Now
                });

                // Sayfayı navigasyon yığınına ekle
                await Navigation.PushAsync(editPage);

                // Sol menüyü (Flyout) otomatik kapat
                FlyoutIsPresented = false;
            }
            else
            {
                // Sayfa servis olarak kaydedilmemişse hata uyarısı
                await Shell.Current.DisplayAlertAsync("Hata",
                    "Sayfa servisi bulunamadı. MauiProgram.cs dosyasını kontrol edin.", "Tamam");
            }
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlertAsync("Navigasyon Hatası", ex.Message, "Tamam");
        }
    }
}
